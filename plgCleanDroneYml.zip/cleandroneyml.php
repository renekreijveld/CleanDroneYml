<?php
defined('_JEXEC') or die;

class PlgSystemCleandroneyml extends JPlugin
{
    // This plugin does nothing, see the plugin description for details
}
